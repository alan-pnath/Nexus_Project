import React from 'react';

export const TeacherContext = React.createContext();
