import React from 'react';

export const StudentContext = React.createContext();
